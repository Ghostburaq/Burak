Capture  On
Section  Heatrun
Instrumentation  Full
Load  0kw 1.0cos� 00:00:00 No
Delay  00:00:10
Load  187kw 1.0cos� 00:00:00 No
Delay  00:00:10
Load  375kw 1.0cos� 00:00:00 No
Delay  00:00:10
Load  0kw 1.0cos� 00:00:00 No
Delay  00:00:10
Reject
Capture  Off
