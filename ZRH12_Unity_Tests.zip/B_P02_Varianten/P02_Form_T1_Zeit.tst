'    ZRH12 P02 - COLD START RAMP ACCEPTANCE
'    Rampe 187 auf 2298 kW in 30 s, 16 Schritte, fuenf Delays mit 2 s
'    Mobil in Time AG - B. Uecoez
Capture  On
Section  Heatrun
Instrumentation  Full
Load  0kw 1cos� 00:00:00 No
Delay  00:00:30
Load  187kw 1cos� 00:00:00 No
Delay  00:00:17
Load  319kw 1cos� 00:00:00 No
Delay  00:00:01
Load  451kw 1cos� 00:00:00 No
Delay  00:00:02
Load  583kw 1cos� 00:00:00 No
Delay  00:00:01
Load  715kw 1cos� 00:00:00 No
Delay  00:00:01
Load  847kw 1cos� 00:00:00 No
Delay  00:00:02
Load  979kw 1cos� 00:00:00 No
Delay  00:00:01
Load  1111kw 1cos� 00:00:00 No
Delay  00:00:01
Load  1242kw 1cos� 00:00:00 No
Delay  00:00:02
Load  1374kw 1cos� 00:00:00 No
Delay  00:00:01
Load  1506kw 1cos� 00:00:00 No
Delay  00:00:01
Load  1638kw 1cos� 00:00:00 No
Delay  00:00:02
Load  1770kw 1cos� 00:00:00 No
Delay  00:00:01
Load  1902kw 1cos� 00:00:00 No
Delay  00:00:01
Load  2034kw 1cos� 00:00:00 No
Delay  00:00:02
Load  2166kw 1cos� 00:00:00 No
Delay  00:00:01
Load  2298kw 1cos� 00:00:00 No
Delay  00:01:00
Load  1800kw 1cos� 00:00:00 No
Delay  00:00:01
Load  1200kw 1cos� 00:00:00 No
Delay  00:00:01
Load  700kw 1cos� 00:00:00 No
Delay  00:00:01
Load  200kw 1cos� 00:00:00 No
Delay  00:00:01
Load  0kw 1cos� 00:00:00 No
Delay  00:02:00
Reject
Capture  Off
